function Customer() {
  return <h2>👋 Welcome, %NAME%</h2>;
}

export default Customer;
